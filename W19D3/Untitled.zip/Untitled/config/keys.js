module.exports = {
  MONGO_URI: 'mongodb+srv://dev:yC1HS58OeiVvuMID@cluster0-mejsw.mongodb.net/test?retryWrites=true&w=majority',
  secretOrKey: 'j8jcw9jw4jfi4nfjeir99932nf',
  AWSKey: 'FQz38ektg163fCZ5mCNMr9KVnzJcLvcU6F9FPrB0'
}